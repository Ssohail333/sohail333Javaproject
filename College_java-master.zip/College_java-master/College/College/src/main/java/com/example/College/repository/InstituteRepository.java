package com.example.College.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.College.model.Institute;

public interface InstituteRepository extends JpaRepository<Institute,Long> {

}
